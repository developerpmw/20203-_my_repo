package model;
import java.awt.Image;


/*--------------------------------------------------------------------------------------------

박민우 : SaveVariable.java 파일 전체 직접 코딩하였습니다.

---------------------------------------------------------------------------------------------- */


public class SaveVariable {
	public static String save_image;
}
