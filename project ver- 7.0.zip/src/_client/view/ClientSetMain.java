package _client.view;


/*--------------------------------------------------------------------------------------------

박민우 : ClientSetMain.java 파일 이름을 구현된 기능에 걸맞게 변경하였습니다.

---------------------------------------------------------------------------------------------- */


public class ClientSetMain {
	public static void main(String[] args) {
		ClientSet set = new ClientSet();
	}
}
