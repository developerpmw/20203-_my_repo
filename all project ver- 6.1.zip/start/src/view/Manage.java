package view;

import javax.swing.JFrame;
@SuppressWarnings("serial")
public abstract class Manage extends JFrame{
	public Seat_panAb pan[]=new Seat_panAb[50];
}
