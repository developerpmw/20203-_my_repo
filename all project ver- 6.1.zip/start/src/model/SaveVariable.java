package model;
import java.awt.Image;

public class SaveVariable {
	public static String save_image;
}
