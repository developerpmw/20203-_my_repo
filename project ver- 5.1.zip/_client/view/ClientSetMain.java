package _client.view;


public class ClientSetMain {
	public static void main(String[] args) {
		ClientSet set = new ClientSet();
	}
}
